chrome.tabs.executeScript({
    document.querySelectorAll('.hideMe').forEach(el => el.style.display = 'none');
});