document.querySelectorAll("#s-hotsearch-wrapper").forEach(function(el) {
    el.style.display = "none";
  });
  