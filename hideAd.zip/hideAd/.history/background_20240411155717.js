chrome.tabs.executeScript({
    document.querySelectorAll('#s-hotsearch-wrapper').forEach(el => el.style.display = 'none');
});