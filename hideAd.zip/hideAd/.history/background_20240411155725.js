chrome.tabs.executeScript({
    code: document.querySelectorAll('#s-hotsearch-wrapper').forEach(el => el.style.display = 'none');
});