document.querySelectorAll("#s-hotsearch-wrapper").forEach(function(el) {
    el.style.display = "none";
});

document.querySelectorAll("#con-ceiling-wrapper").forEach(function(el) {
    el.style.display = "none";
});